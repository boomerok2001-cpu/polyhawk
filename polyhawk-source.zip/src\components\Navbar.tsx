'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import EagleLogo from './EagleLogo';

export default function Navbar() {
    const pathname = usePathname();

    return (
        <nav className="navbar" style={{ position: 'sticky', top: 0, zIndex: 1000, background: 'rgba(10, 11, 13, 0.8)', backdropFilter: 'blur(12px)', borderBottom: '1px solid var(--border)' }}>
            <div className="container navbar-content" style={{ padding: '0 1rem', display: 'flex', height: '64px', alignItems: 'center' }}>
                {/* Left: Logo */}
                <Link href="/" className="logo" style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                    <EagleLogo />
                    <span style={{ fontWeight: 800, letterSpacing: '-0.02em', fontSize: '1.25rem' }}>POLY<span className="text-primary">HAWK</span></span>
                </Link>

                {/* Center/Desktop Navigation */}
                <div className="desktop-links" style={{ display: 'flex', gap: '1.5rem', alignItems: 'center', marginLeft: '2rem' }}>
                    <Link href="/markets" className={`nav-link-v2 ${pathname === '/markets' ? 'active' : ''}`}>Markets</Link>
                    <Link href="/news" className={`nav-link-v2 ${pathname === '/news' ? 'active' : ''}`}>News</Link>
                    <Link href="/wallet-checker" className={`nav-link-v2 ${pathname === '/wallet-checker' ? 'active' : ''}`}>Whales</Link>
                    <Link href="/learn" className={`nav-link-v2 ${pathname === '/learn' ? 'active' : ''}`}>Learn</Link>
                    <Link href="/portfolio" className={`nav-link-v2 ${pathname === '/portfolio' ? 'active' : ''}`}>Portfolio</Link>
                </div>
            </div>

            <style jsx>{`
                .nav-link-v2 {
                    color: var(--text-secondary);
                    text-decoration: none;
                    font-size: 0.95rem;
                    font-weight: 700;
                    transition: all 0.2s;
                    padding: 0.5rem 0.5rem;
                    letter-spacing: -0.01em;
                }
                .nav-link-v2:hover, .nav-link-v2.active {
                    color: var(--text-main);
                }
                .nav-link-v2.active {
                    color: var(--primary);
                }
                
                @media (max-width: 1024px) {
                    .desktop-links {
                        display: flex !important;
                        gap: 1rem;
                    }
                    .nav-link-v2 {
                        font-size: 0.85rem;
                    }
                }
                
                @media (max-width: 640px) {
                    .desktop-links {
                        margin-left: auto;
                        gap: 0.75rem;
                    }
                    .nav-link-v2 {
                        font-size: 0.8rem;
                        padding: 0.4rem 0.4rem;
                    }
                }
                .text-primary { color: var(--primary); }
            `}</style>
        </nav>
    );
}
