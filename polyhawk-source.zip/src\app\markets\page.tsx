import Link from 'next/link';
import { fetchPolyscalpingTrending, fetchPolyscalpingMarketsByCategory } from '@/lib/polyscalping-api';
import { formatCurrency } from '@/data/markets';

// This is a server component
export default async function MarketsPage({
    searchParams,
}: {
    searchParams: Promise<{ filter?: string }>;
}) {
    // 1. Determine which data to fetch based on filter
    // Default to 'active' (trending/live)
    const params = await searchParams;
    const filter = params.filter || 'live';

    let markets: any[] = [];
    let title = 'Live Markets';
    let subtitle = 'Currently active prediction markets';

    if (filter === 'new') {
        // Get all markets and sort by creation date
        markets = await fetchPolyscalpingTrending(100);
        markets = markets.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).slice(0, 50);
        title = 'New Markets';
        subtitle = 'Recently created markets';
    } else if (filter === 'resolved') {
        // Polyscalping doesn't have resolved markets, use empty array
        markets = [];
        title = 'Resolved Markets';
        subtitle = 'Markets that have ended';
    } else if (filter === 'politics') {
        markets = await fetchPolyscalpingMarketsByCategory('Politics');
        title = 'Politics';
        subtitle = 'Election odds and political events';
    } else if (filter === 'crypto') {
        markets = await fetchPolyscalpingMarketsByCategory('Crypto');
        title = 'Crypto';
        subtitle = 'Price predictions and protocol markets';
    } else if (filter === 'sports') {
        markets = await fetchPolyscalpingMarketsByCategory('Sports');
        title = 'Sports';
        subtitle = 'Live sports betting odds';
    } else if (filter === 'economics') {
        markets = await fetchPolyscalpingMarketsByCategory('Economics');
        title = 'Economics';
        subtitle = 'Fed rates, GDP, and economic indicators';
    } else if (filter === 'science') {
        markets = await fetchPolyscalpingMarketsByCategory('Science');
        title = 'Science';
        subtitle = 'Scientific breakthroughs and tech developments';
    } else if (filter === 'pop-culture') {
        markets = await fetchPolyscalpingMarketsByCategory('Pop Culture');
        title = 'Pop Culture';
        subtitle = 'Entertainment, celebrity, and social events';
    } else {
        markets = await fetchPolyscalpingTrending();
    }

    const categories = [
        { id: 'live', label: '⚡ Live Markets' },
        { id: 'new', label: '🆕 New Markets' },
        { id: 'politics', label: '⚖️ Politics' },
        { id: 'crypto', label: '₿ Crypto' },
        { id: 'sports', label: '⚽ Sports' },
        { id: 'economics', label: '📈 Economics' },
        { id: 'science', label: '🧬 Science' },
        { id: 'pop-culture', label: '🎭 Pop Culture' },
        { id: 'resolved', label: '🏁 Resolved' },
    ];

    return (
        <main className="container" style={{ paddingBottom: '4rem', display: 'flex', gap: '2rem', marginTop: '4rem' }}>

            {/* Sidebar Navigation */}
            <aside style={{ width: '250px', flexShrink: 0 }}>
                <div style={{ position: 'sticky', top: '100px' }}>
                    <h3 style={{ fontSize: '0.75rem', fontWeight: 700, marginBottom: '1rem', paddingLeft: '0.75rem', color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Filters</h3>

                    {/* Main Categories */}
                    <nav style={{ display: 'flex', flexDirection: 'column', gap: '0.25rem', marginBottom: '1.5rem' }}>
                        {[
                            { id: 'live', label: '⚡ Live Markets' },
                            { id: 'new', label: '🆕 New Markets' },
                        ].map(cat => (
                            <Link
                                key={cat.id}
                                href={`/markets?filter=${cat.id}`}
                                style={{
                                    padding: '0.7rem 0.75rem',
                                    borderRadius: '8px',
                                    textDecoration: 'none',
                                    background: filter === cat.id ? 'rgba(59, 130, 246, 0.12)' : 'transparent',
                                    color: filter === cat.id ? 'var(--primary)' : 'var(--text-secondary)',
                                    fontWeight: filter === cat.id ? 600 : 500,
                                    fontSize: '0.9rem',
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '0.6rem',
                                    transition: 'all 0.15s ease',
                                    borderLeft: filter === cat.id ? '3px solid var(--primary)' : '3px solid transparent',
                                    paddingLeft: filter === cat.id ? '0.65rem' : '0.75rem'
                                }}
                                className="category-link"
                            >
                                <span style={{ fontSize: '1.1rem', opacity: 0.9 }}>{cat.label.split(' ')[0]}</span>
                                <span>{cat.label.split(' ').slice(1).join(' ')}</span>
                            </Link>
                        ))}
                    </nav>

                    {/* Category Divider */}
                    <div style={{ height: '1px', background: 'var(--border)', marginBottom: '1.5rem' }}></div>

                    {/* Topic Categories */}
                    <div style={{ marginBottom: '0.5rem', paddingLeft: '0.75rem' }}>
                        <span style={{ fontSize: '0.7rem', fontWeight: 700, color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Topics</span>
                    </div>
                    <nav style={{ display: 'flex', flexDirection: 'column', gap: '0.25rem', marginBottom: '1.5rem' }}>
                        {[
                            { id: 'politics', label: '⚖️ Politics' },
                            { id: 'crypto', label: '₿ Crypto' },
                            { id: 'sports', label: '⚽ Sports' },
                        ].map(cat => (
                            <Link
                                key={cat.id}
                                href={`/markets?filter=${cat.id}`}
                                style={{
                                    padding: '0.65rem 0.75rem',
                                    borderRadius: '8px',
                                    textDecoration: 'none',
                                    background: filter === cat.id ? 'rgba(59, 130, 246, 0.12)' : 'transparent',
                                    color: filter === cat.id ? 'var(--primary)' : 'var(--text-secondary)',
                                    fontWeight: filter === cat.id ? 600 : 500,
                                    fontSize: '0.88rem',
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '0.6rem',
                                    transition: 'all 0.15s ease',
                                    borderLeft: filter === cat.id ? '3px solid var(--primary)' : '3px solid transparent',
                                    paddingLeft: filter === cat.id ? '0.65rem' : '0.75rem'
                                }}
                                className="category-link"
                            >
                                <span style={{ fontSize: '1rem', opacity: 0.85 }}>{cat.label.split(' ')[0]}</span>
                                <span>{cat.label.split(' ').slice(1).join(' ')}</span>
                            </Link>
                        ))}
                    </nav>

                    {/* Category Divider */}
                    <div style={{ height: '1px', background: 'var(--border)', marginBottom: '1.5rem' }}></div>

                    {/* Status */}
                    <div style={{ marginBottom: '0.5rem', paddingLeft: '0.75rem' }}>
                        <span style={{ fontSize: '0.7rem', fontWeight: 700, color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Status</span>
                    </div>
                    <nav style={{ display: 'flex', flexDirection: 'column', gap: '0.25rem' }}>
                        {[
                            { id: 'resolved', label: '🏁 Resolved' },
                        ].map(cat => (
                            <Link
                                key={cat.id}
                                href={`/markets?filter=${cat.id}`}
                                style={{
                                    padding: '0.65rem 0.75rem',
                                    borderRadius: '8px',
                                    textDecoration: 'none',
                                    background: filter === cat.id ? 'rgba(59, 130, 246, 0.12)' : 'transparent',
                                    color: filter === cat.id ? 'var(--primary)' : 'var(--text-secondary)',
                                    fontWeight: filter === cat.id ? 600 : 500,
                                    fontSize: '0.88rem',
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '0.6rem',
                                    transition: 'all 0.15s ease',
                                    borderLeft: filter === cat.id ? '3px solid var(--primary)' : '3px solid transparent',
                                    paddingLeft: filter === cat.id ? '0.65rem' : '0.75rem'
                                }}
                                className="category-link"
                            >
                                <span style={{ fontSize: '1rem', opacity: 0.85 }}>{cat.label.split(' ')[0]}</span>
                                <span>{cat.label.split(' ').slice(1).join(' ')}</span>
                            </Link>
                        ))}
                    </nav>
                </div>
            </aside>

            {/* Main Content Area */}
            <div style={{ flex: 1 }}>
                <div style={{ marginBottom: '2rem' }}>
                    <h1 style={{ fontSize: '2.5rem', fontWeight: 800, marginBottom: '0.5rem' }}>{title}</h1>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
                        <p className="text-secondary">{subtitle}</p>
                        <span className="text-secondary">•</span>
                        <p className="text-secondary" style={{ fontSize: '0.9rem' }}>
                            Data provided by <a href="https://polyscalping.org" target="_blank" rel="noopener noreferrer" style={{ color: 'var(--primary)' }}>Polyscalping.org</a>
                        </p>
                    </div>
                </div>

                <div style={{ background: 'var(--surface)', borderRadius: '24px', border: '1px solid var(--border)', overflow: 'hidden' }}>
                    <div style={{ overflowX: 'auto' }}>
                        <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: '900px' }}>
                            <thead>
                                <tr style={{ borderBottom: '1px solid var(--border)', textAlign: 'left' }}>
                                    <th style={{ padding: '1rem 1.5rem', color: 'var(--text-secondary)', fontWeight: 600 }}>Market</th>
                                    <th style={{ padding: '1rem', color: 'var(--text-secondary)', fontWeight: 600 }}>Price</th>
                                    <th style={{ padding: '1rem', color: 'var(--text-secondary)', fontWeight: 600 }}>Spread</th>
                                    <th style={{ padding: '1rem', color: 'var(--text-secondary)', fontWeight: 600 }}>Liquidity</th>
                                    <th style={{ padding: '1rem', color: 'var(--text-secondary)', fontWeight: 600 }}>Volume 24h</th>
                                    <th style={{ padding: '1rem', color: 'var(--text-secondary)', fontWeight: 600 }}>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                {markets.map((market, i) => (
                                    <tr key={market.id} style={{ borderBottom: '1px solid var(--border)' }}>
                                        <td style={{ padding: '1rem 1.5rem' }}>
                                            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                                                <span style={{ color: 'var(--text-secondary)', width: '20px' }}>{i + 1}</span>
                                                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                                                    {market.image && (
                                                        <img
                                                            src={market.image}
                                                            alt=""
                                                            style={{ width: '32px', height: '32px', borderRadius: '8px', objectFit: 'cover' }}
                                                        />
                                                    )}
                                                    <Link href={`https://polymarket.com/event/${market.eventSlug}?tid=${market.id}`} target="_blank" style={{ fontWeight: 600, color: 'var(--text-main)', textDecoration: 'none' }}>
                                                        {market.market}
                                                    </Link>
                                                </div>
                                            </div>
                                        </td>
                                        <td style={{ padding: '1rem' }}>
                                            <div style={{ display: 'flex', gap: '8px' }}>
                                                <span className="price-indicator price-yes">{(market.lastPrice * 100).toFixed(1)}%</span>
                                            </div>
                                        </td>
                                        <td style={{ padding: '1rem' }}>
                                            <span style={{
                                                color: market.spreadPercent < 1 ? '#22c55e' : market.spreadPercent < 3 ? '#eab308' : '#ef4444',
                                                fontWeight: 600
                                            }}>
                                                {market.spreadPercent.toFixed(2)}%
                                            </span>
                                        </td>
                                        <td style={{ padding: '1rem', fontWeight: 500 }}>
                                            {formatCurrency(market.liquidity)}
                                        </td>
                                        <td style={{ padding: '1rem', fontWeight: 500 }}>
                                            {formatCurrency(market.volume24h)}
                                        </td>
                                        <td style={{ padding: '1rem' }}>
                                            <Link href={`https://polymarket.com/event/${market.eventSlug}?tid=${market.id}`} target="_blank" className="btn btn-secondary" style={{ padding: '0.4rem 0.8rem', fontSize: '0.85rem' }}>
                                                Trade
                                            </Link>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                    {markets.length === 0 && (
                        <div style={{ padding: '4rem', textAlign: 'center', color: 'var(--text-secondary)' }}>
                            No markets found in this category currently.
                        </div>
                    )}
                </div>
            </div>
        </main>
    );
}
