'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Market } from '@/lib/api';
import { formatCurrency } from '@/data/markets';

interface HomeMarketTableProps {
    initialMarkets: Market[];
}

export default function HomeMarketTable({ initialMarkets }: HomeMarketTableProps) {
    const [displayCount, setDisplayCount] = useState(10);
    const hasMore = initialMarkets.length > displayCount;

    const visibleMarkets = initialMarkets.slice(0, displayCount);

    return (
        <div style={{ background: 'var(--surface)', borderRadius: '24px', border: '1px solid var(--border)', overflow: 'hidden', marginBottom: '5rem' }}>
            <div style={{ padding: '1.5rem', borderBottom: '1px solid var(--border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <h2 style={{ fontSize: '1.5rem', fontWeight: 700 }}>Top Markets by Volume</h2>
                <Link href="/markets" className="btn btn-outline" style={{ fontSize: '0.9rem', padding: '0.5rem 1rem' }}>View All Markets</Link>
            </div>

            <div style={{ overflowX: 'auto' }}>
                <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: '800px' }}>
                    <thead>
                        <tr style={{ borderBottom: '1px solid var(--border)', textAlign: 'left' }}>
                            <th style={{ padding: '1rem 1.5rem', color: 'var(--text-secondary)', fontWeight: 600 }}>Market</th>
                            <th style={{ padding: '1rem', color: 'var(--text-secondary)', fontWeight: 600 }}>Price (Yes)</th>
                            <th style={{ padding: '1rem', color: 'var(--text-secondary)', fontWeight: 600 }}>Price (No)</th>
                            <th style={{ padding: '1rem', color: 'var(--text-secondary)', fontWeight: 600 }}>Volume (24h)</th>
                            <th style={{ padding: '1rem', color: 'var(--text-secondary)', fontWeight: 600 }}>Source</th>
                            <th style={{ padding: '1rem', color: 'var(--text-secondary)', fontWeight: 600 }}></th>
                        </tr>
                    </thead>
                    <tbody>
                        {visibleMarkets.map((market, i) => (
                            <tr key={`${market.source}-${market.id}`} style={{ borderBottom: '1px solid var(--border)' }}>
                                <td style={{ padding: '1rem 1.5rem' }}>
                                    <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                                        <span style={{ color: 'var(--text-secondary)', width: '20px' }}>{i + 1}</span>
                                        <Link href={`/market/${market.id}`} style={{ fontWeight: 600, color: 'var(--text-main)', textDecoration: 'none' }}>
                                            {market.title}
                                        </Link>
                                    </div>
                                </td>
                                <td style={{ padding: '1rem' }}>
                                    <span style={{
                                        padding: '0.4rem 0.8rem',
                                        borderRadius: '8px',
                                        background: 'rgba(59, 130, 246, 0.1)',
                                        color: 'var(--primary)',
                                        fontWeight: 700
                                    }}>
                                        {(market.yesPrice * 100).toFixed(1)}¢
                                    </span>
                                </td>
                                <td style={{ padding: '1rem' }}>
                                    <span style={{
                                        padding: '0.4rem 0.8rem',
                                        borderRadius: '8px',
                                        background: 'rgba(239, 68, 68, 0.1)',
                                        color: '#ef4444',
                                        fontWeight: 700
                                    }}>
                                        {(market.noPrice * 100).toFixed(1)}¢
                                    </span>
                                </td>
                                <td style={{ padding: '1rem', fontWeight: 500 }}>
                                    ${Number(market.volume).toLocaleString(undefined, { maximumFractionDigits: 0 })}
                                </td>
                                <td style={{ padding: '1rem' }}>
                                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                                        <div style={{ width: '8px', height: '8px', borderRadius: '50%', background: market.source === 'Polymarket' ? 'var(--primary)' : '#10b981' }}></div>
                                        {market.source}
                                    </div>
                                </td>
                                <td style={{ padding: '1rem' }}>
                                    <Link href={`/market/${market.id}`} className="btn btn-secondary" style={{ padding: '0.4rem 0.8rem', fontSize: '0.85rem' }}>
                                        Trade
                                    </Link>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {hasMore && (
                <div style={{ padding: '1.5rem', textAlign: 'center', borderTop: '1px solid var(--border)' }}>
                    <button
                        onClick={() => setDisplayCount(prev => prev + 20)}
                        className="btn btn-outline"
                        style={{ width: '200px', fontWeight: 700 }}
                    >
                        Show More
                    </button>
                </div>
            )}
        </div>
    );
}
