import { NextResponse } from 'next/server';
import { fetchPolyscalpingMarkets } from '@/lib/polyscalping-api';

export const revalidate = 3600; // Cache for 1 hour

export async function GET() {
    try {
        const markets = await fetchPolyscalpingMarkets();

        // Create a map of Slug -> Category & Image
        // We use eventSlug as well because positions often link to event
        const metadata: Record<string, { category: string, image: string }> = {};

        markets.forEach(m => {
            // Map strict market slug
            if (m.marketSlug) {
                metadata[m.marketSlug] = { category: m.category, image: m.image };
            }
            // Map event slug (often same prefix)
            if (m.eventSlug) {
                metadata[m.eventSlug] = { category: m.category, image: m.image };
            }
        });

        return NextResponse.json(metadata);
    } catch (error) {
        console.error('Error fetching market metadata:', error);
        return NextResponse.json({ error: 'Failed to fetch market metadata' }, { status: 500 });
    }
}
