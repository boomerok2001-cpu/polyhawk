import Link from 'next/link';
import { fetchPolymarketTrending, fetchKalshiMarkets, fetchNews, POLYMARKET_REFERRAL } from '@/lib/api';
import { fetchPolyscalpingTrending, fetchPolyscalpingMarketsByCategory } from '@/lib/polyscalping-api';
import { formatCurrency } from '@/data/markets';
import NewsletterSection from '@/components/NewsletterSection';
import HawkoButton from '@/components/HawkoButton';
import HomeMarketTable from '@/components/HomeMarketTable';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

// Mock Featured Articles (Subset of Learn)
const FEATURED_ARTICLES = [
  {
    slug: 'what-are-prediction-markets',
    title: 'What Are Prediction Markets?',
    category: 'Basics',
    readTime: '5 min',
    image: 'https://images.unsplash.com/photo-1642543492481-44e81e3914a7?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
  },
  {
    slug: 'how-to-arbitrage',
    title: 'Arbitrage Strategy 101',
    category: 'Strategy',
    readTime: '8 min',
    image: 'https://images.unsplash.com/photo-1611974765270-ca1258634369?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
  }
];

export default async function Home() {
  const [polymarketData, kalshiData, news, polyscalpingMarkets] = await Promise.all([
    fetchPolymarketTrending(),
    fetchKalshiMarkets(),
    fetchNews(),
    fetchPolyscalpingTrending(100)
  ]);

  // Get top gainers (markets with highest 24h price change)
  const topGainers = polyscalpingMarkets
    .filter(m => m.priceChange24h > 0)
    .sort((a, b) => b.priceChange24h - a.priceChange24h)
    .slice(0, 6)
    .map(m => ({
      id: m.id.toString(),
      title: m.market,
      source: 'Polymarket',
      yesPrice: m.lastPrice,
      noPrice: 1 - m.lastPrice,
      volume: m.volume24h,
      change24h: m.priceChange24h,
      category: m.category
    }));

  // Get sports markets
  const sportsMarketsRaw = await fetchPolyscalpingMarketsByCategory('Sports');
  const sportsMarkets = sportsMarketsRaw.slice(0, 4).map(m => ({
    id: m.id.toString(),
    title: m.market,
    source: 'Polymarket',
    yesPrice: m.lastPrice,
    noPrice: 1 - m.lastPrice,
    volume: m.volume24h,
    category: m.category,
    image: m.image
  }));

  // Get new markets (sorted by creation date)
  const newMarkets = polyscalpingMarkets
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 8)
    .map(m => ({
      id: m.id.toString(),
      title: m.market,
      source: 'Polymarket',
      yesPrice: m.lastPrice,
      noPrice: 1 - m.lastPrice,
      volume: m.volume24h,
      category: m.category
    }));

  // Calculate dynamic stats
  const total24hVol = [...polymarketData, ...kalshiData].reduce((sum, m) => sum + m.volume, 0);
  const totalActiveMarkets = polymarketData.length + kalshiData.length;
  const avgLiquidity = [...polymarketData, ...kalshiData].reduce((sum, m) => sum + (m.liquidity || 0), 0) / (totalActiveMarkets || 1);

  // Combine and sort by volume for the main table (Initial load)
  const allMarketsSorted = [...polymarketData, ...kalshiData]
    .sort((a, b) => b.volume - a.volume);

  return (
    <main className="container" style={{ paddingBottom: '4rem' }}>
      {/* Hero Section */}
      <div style={{ padding: '4rem 0', textAlign: 'center' }}>
        <h1 className="hero-title" style={{ fontSize: '4.5rem', fontWeight: 900, letterSpacing: '-0.04em', lineHeight: 1.1, marginBottom: '1.5rem', background: 'linear-gradient(135deg, #fff 0%, #a1a1aa 100%)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
          Real-Time Prediction <br />
          Market <span className="text-primary">Intelligence</span>
        </h1>
        <p className="hero-subtitle" style={{ fontSize: '1.25rem', color: 'var(--text-secondary)', marginBottom: '3rem', maxWidth: '600px', margin: '0 auto 3rem', lineHeight: 1.6 }}>
          Aggregating prediction markets and deeper on-chain insights. Track whales, find arbitrage, and master the markets.
        </p>
        <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center' }}>
          <a href={POLYMARKET_REFERRAL} target="_blank" className="btn btn-primary" style={{ fontSize: '1.1rem', padding: '0.8rem 2rem' }}>
            Trade on Polymarket
          </a>
          <HawkoButton />
        </div>
      </div>

      {/* Market Stats Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1.5rem', marginBottom: '4rem' }}>
        <div style={{ background: 'var(--surface)', padding: '1.5rem', borderRadius: '24px', border: '1px solid var(--border)', boxShadow: '0 4px 20px rgba(0,0,0,0.1)' }}>
          <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '0.5rem' }}>Global Volume (24h)</div>
          <div style={{ fontSize: '2.5rem', fontWeight: 900, letterSpacing: '-0.02em', color: 'var(--text-main)' }}>${(total24hVol / 1000000).toFixed(1)}M</div>
          <div className="text-green" style={{ fontSize: '0.9rem', fontWeight: 600 }}>↑ Dynamic Real-time</div>
        </div>
        <div style={{ background: 'var(--surface)', padding: '1.5rem', borderRadius: '24px', border: '1px solid var(--border)', boxShadow: '0 4px 20px rgba(0,0,0,0.1)' }}>
          <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '0.5rem' }}>Active Markets</div>
          <div style={{ fontSize: '2.5rem', fontWeight: 900, letterSpacing: '-0.02em', color: 'var(--text-main)' }}>{totalActiveMarkets.toLocaleString()}</div>
          <div className="text-primary" style={{ fontSize: '0.9rem', fontWeight: 600 }}>Across 2 Platforms</div>
        </div>
        <div style={{ background: 'var(--surface)', padding: '1.5rem', borderRadius: '24px', border: '1px solid var(--border)', boxShadow: '0 4px 20px rgba(0,0,0,0.1)' }}>
          <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '0.5rem' }}>Avg Liquidity/Order</div>
          <div style={{ fontSize: '2.5rem', fontWeight: 900, letterSpacing: '-0.02em', color: 'var(--text-main)' }}>${(avgLiquidity / 1000).toFixed(1)}k</div>
          <div className="text-green" style={{ fontSize: '0.9rem', fontWeight: 600 }}>Stable Depth</div>
        </div>
      </div>

      {/* Portfolio & News Dashboard Preview */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(350px, 1fr))', gap: '2rem', marginBottom: '5rem' }}>
        {/* Portfolio Intelligence Preview */}
        <div style={{
          background: 'linear-gradient(145deg, rgba(59, 130, 246, 0.15) 0%, rgba(30, 58, 138, 0.1) 100%)',
          borderRadius: '32px',
          padding: '2.5rem',
          border: '1px solid rgba(59, 130, 246, 0.3)',
          display: 'flex',
          flexDirection: 'column',
          position: 'relative',
          overflow: 'hidden'
        }}>
          {/* Decorative background visual */}
          <div style={{ position: 'absolute', top: '10%', right: '-5%', width: '150px', height: '150px', background: 'var(--primary)', filter: 'blur(80px)', opacity: 0.15, borderRadius: '50%' }}></div>

          <div style={{ position: 'relative', zIndex: 1 }}>
            <div style={{ fontSize: '0.8rem', color: 'var(--primary)', fontWeight: 800, textTransform: 'uppercase', marginBottom: '1rem', letterSpacing: '0.15em' }}>
              Pro features
            </div>
            <h2 style={{ fontSize: '2.5rem', fontWeight: 900, marginBottom: '1rem', lineHeight: 1.1, letterSpacing: '-0.03em' }}>
              Universal <span className="text-primary">Portfolio</span>
            </h2>
            <p style={{ color: 'var(--text-secondary)', marginBottom: '2.5rem', fontSize: '1.1rem', lineHeight: 1.6, maxWidth: '90%' }}>
              Connect your wallet to experience the world's most advanced prediction market dashboard.
            </p>

            <div style={{ display: 'flex', gap: '1rem', marginBottom: '2.5rem' }}>
              <Link href="/portfolio" className="btn btn-primary" style={{ padding: '0.8rem 1.75rem', fontSize: '1rem' }}>
                Open Portfolio
              </Link>
              <Link href="/wallet-checker" className="btn btn-secondary" style={{ padding: '0.8rem 1.75rem', fontSize: '1rem', background: 'rgba(255,255,255,0.05)' }}>
                Whale Tracker
              </Link>
            </div>

            {/* Visual Teaser: Premium Card UI */}
            <div style={{
              background: 'rgba(255, 255, 255, 0.03)',
              backdropFilter: 'blur(10px)',
              borderRadius: '20px',
              padding: '1.5rem',
              border: '1px solid rgba(255, 255, 255, 0.05)',
              display: 'flex',
              flexDirection: 'column',
              gap: '1rem'
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: '0.8rem', fontWeight: 600, color: 'var(--text-secondary)' }}>Net Performance</span>
                <span style={{ fontSize: '0.8rem', fontWeight: 800, color: '#22c55e' }}>+24.8% APY</span>
              </div>
              <div style={{ height: '40px', display: 'flex', alignItems: 'flex-end', gap: '4px' }}>
                {[30, 45, 25, 60, 40, 75, 55, 90].map((h, i) => (
                  <div key={i} style={{ flex: 1, height: `${h}%`, background: 'var(--primary)', borderRadius: '2px', opacity: 0.3 + (i * 0.1) }}></div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Live News Pulse */}
        <div style={{
          background: 'var(--surface)',
          borderRadius: '32px',
          border: '1px solid var(--border)',
          padding: '2rem',
          boxShadow: '0 4px 30px rgba(0,0,0,0.15)'
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
            <h2 style={{ fontSize: '1.6rem', fontWeight: 900 }}>Latest Pulse</h2>
            <Link href="/news" className="btn btn-outline" style={{ padding: '0.4rem 1rem', fontSize: '0.8rem' }}>View All</Link>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
            {news.slice(0, 3).map(item => (
              <a href={item.url} target="_blank" key={item.id} style={{ textDecoration: 'none', color: 'inherit', display: 'flex', gap: '1.25rem', alignItems: 'center' }}>
                <div style={{ width: '70px', height: '70px', borderRadius: '16px', background: 'var(--bg)', overflow: 'hidden', flexShrink: 0, border: '1px solid var(--border)' }}>
                  <img src={item.imageUrl} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                </div>
                <div>
                  <div style={{ fontSize: '0.75rem', color: 'var(--primary)', fontWeight: 800, textTransform: 'uppercase', marginBottom: '4px' }}>{item.source} • {item.time}</div>
                  <h3 style={{ fontSize: '1.05rem', fontWeight: 700, lineHeight: 1.3 }}>{item.title}</h3>
                </div>
              </a>
            ))}
          </div>
        </div>
      </div>

      {/* Top Gainers Section */}
      <div style={{ marginBottom: '4rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '1.5rem' }}>
          <h2 style={{ fontSize: '1.75rem', fontWeight: 800 }}>🚀 Top Gainers</h2>
          <span style={{ fontSize: '0.9rem', padding: '2px 8px', background: 'rgba(34, 197, 94, 0.1)', color: '#22c55e', borderRadius: '4px', fontWeight: 600 }}>24h</span>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1.5rem' }}>
          {topGainers.map(market => (
            <Link href={`/market/${market.id}`} key={market.id} style={{ textDecoration: 'none' }}>
              <div className="card-hover" style={{
                background: 'var(--surface)',
                border: '1px solid var(--border)',
                borderRadius: '16px',
                padding: '1.5rem',
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1rem' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
                    <div style={{ width: '6px', height: '6px', borderRadius: '50%', background: 'var(--primary)' }}></div>
                    {market.source}
                  </div>
                  <span style={{ color: '#22c55e', fontWeight: 700 }}>+{market.change24h.toFixed(1)}%</span>
                </div>
                <h3 style={{ fontSize: '1.1rem', fontWeight: 600, marginBottom: '1.5rem', lineHeight: 1.4, height: '3rem', overflow: 'hidden', color: 'var(--text-main)' }}>
                  {market.title}
                </h3>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div>
                    <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>Yes Price</div>
                    <div style={{ fontSize: '1.2rem', fontWeight: 700, color: 'var(--primary)' }}>{(market.yesPrice * 100).toFixed(1)}¢</div>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>Volume</div>
                    <div style={{ fontWeight: 600 }}>${(market.volume / 1000).toFixed(1)}k</div>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>

      {/* NEW: Live Sports Section */}
      <div style={{ marginBottom: '4rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.5rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <h2 style={{ fontSize: '1.75rem', fontWeight: 800 }}>⚽ Live Sports</h2>
            <span style={{ fontSize: '0.9rem', padding: '2px 8px', background: '#ef4444', color: '#fff', borderRadius: '4px', fontWeight: 600 }}>LIVE</span>
          </div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '1.5rem' }}>
          {sportsMarkets.map(market => (
            <Link href={`/market/${market.id}`} key={market.id} style={{ textDecoration: 'none' }}>
              <div className="card-hover" style={{
                background: 'var(--surface)',
                border: '1px solid var(--border)',
                borderRadius: '16px',
                overflow: 'hidden'
              }}>
                {market.image && (
                  <div style={{ height: '120px', background: '#111', overflow: 'hidden' }}>
                    <img src={market.image} alt={market.title} style={{ width: '100%', height: '100%', objectFit: 'cover', opacity: 0.8 }} />
                  </div>
                )}
                <div style={{ padding: '1.5rem' }}>
                  <h3 style={{ fontSize: '1.1rem', fontWeight: 600, marginBottom: '1rem', color: 'var(--text-main)' }}>
                    {market.title}
                  </h3>
                  <div style={{ display: 'flex', gap: '0.5rem' }}>
                    <div style={{ flex: 1, background: 'rgba(255,255,255,0.05)', padding: '0.75rem', borderRadius: '8px', textAlign: 'center' }}>
                      <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>Yes</div>
                      <div style={{ fontSize: '1.1rem', fontWeight: 700, color: 'var(--primary)' }}>{(market.yesPrice * 100).toFixed(0)}%</div>
                    </div>
                    <div style={{ flex: 1, background: 'rgba(255,255,255,0.05)', padding: '0.75rem', borderRadius: '8px', textAlign: 'center' }}>
                      <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>No</div>
                      <div style={{ fontSize: '1.1rem', fontWeight: 700, color: '#ef4444' }}>{(market.noPrice * 100).toFixed(0)}%</div>
                    </div>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>

      {/* NEW: New Markets Section */}
      <div style={{ marginBottom: '4rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '1.5rem' }}>
          <h2 style={{ fontSize: '1.75rem', fontWeight: 800 }}>✨ New Markets</h2>
          <span style={{ fontSize: '0.9rem', padding: '2px 8px', background: 'rgba(59, 130, 246, 0.1)', color: 'var(--primary)', borderRadius: '4px', fontWeight: 600 }}>Just In</span>
        </div>
        <div style={{ display: 'flex', gap: '1.5rem', overflowX: 'auto', paddingBottom: '1rem', scrollbarWidth: 'none' }}>
          {newMarkets.map(market => (
            <Link href={`/market/${market.id}`} key={market.id} style={{ textDecoration: 'none', flexShrink: 0, width: '300px' }}>
              <div className="card-hover" style={{
                background: 'var(--surface)',
                border: '1px solid var(--border)',
                borderRadius: '16px',
                padding: '1.5rem',
              }}>
                <div style={{ fontSize: '0.7rem', color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: '0.5rem' }}>{market.category}</div>
                <h3 style={{ fontSize: '1rem', fontWeight: 600, marginBottom: '1rem', color: 'var(--text-main)', height: '2.8rem', overflow: 'hidden' }}>
                  {market.title}
                </h3>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{ fontSize: '0.9rem', fontWeight: 700, color: 'var(--primary)' }}>{(market.yesPrice * 100).toFixed(1)}¢</span>
                  <span style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>Vol: ${(market.volume / 1000).toFixed(1)}k</span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>

      {/* Main Market Table */}
      <HomeMarketTable initialMarkets={allMarketsSorted} />

      {/* News and Articles Section */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '3rem' }}>

        {/* Latest News */}
        <div style={{ flex: 2 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
            <h2 style={{ fontSize: '1.75rem', fontWeight: 800 }}>Latest News</h2>
            <Link href="/news" className="text-primary" style={{ fontWeight: 600 }}>See all &rarr;</Link>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
            {news.slice(0, 4).map(item => (
              <a href={item.url} target="_blank" key={item.id} style={{ textDecoration: 'none', color: 'inherit' }}>
                <div className="card-hover" style={{
                  background: 'var(--surface)',
                  border: '1px solid var(--border)',
                  borderRadius: '16px',
                  padding: '1rem',
                  display: 'flex',
                  gap: '1rem',
                  alignItems: 'center'
                }}>
                  <div style={{ width: '80px', height: '80px', borderRadius: '12px', overflow: 'hidden', flexShrink: 0 }}>
                    <img src={item.imageUrl} alt={item.title} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                  </div>
                  <div>
                    <div style={{ display: 'flex', gap: '8px', marginBottom: '4px', fontSize: '0.8rem', color: 'var(--text-secondary)' }}>
                      <span style={{ fontWeight: 600, color: 'var(--primary)' }}>{item.source}</span>
                      <span>•</span>
                      <span>{item.time}</span>
                    </div>
                    <h3 style={{ fontSize: '1rem', fontWeight: 700, lineHeight: 1.4, marginBottom: '4px' }}>{item.title}</h3>
                  </div>
                </div>
              </a>
            ))}
          </div>
        </div>

        {/* Featured Articles */}
        <div style={{ flex: 1 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
            <h2 style={{ fontSize: '1.75rem', fontWeight: 800 }}>Featured Articles</h2>
            <Link href="/learn" className="text-primary" style={{ fontWeight: 600 }}>Academy &rarr;</Link>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
            {FEATURED_ARTICLES.map(article => (
              <Link href={`/learn/${article.slug}`} key={article.slug} style={{ textDecoration: 'none', color: 'inherit' }}>
                <div className="card-hover" style={{
                  background: 'var(--surface)',
                  border: '1px solid var(--border)',
                  borderRadius: '16px',
                  overflow: 'hidden'
                }}>
                  <div style={{ height: '150px', overflow: 'hidden' }}>
                    <img src={article.image} alt={article.title} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                  </div>
                  <div style={{ padding: '1.25rem' }}>
                    <div style={{ fontSize: '0.8rem', color: 'var(--primary)', fontWeight: 700, marginBottom: '0.5rem', textTransform: 'uppercase' }}>
                      {article.category}
                    </div>
                    <h3 style={{ fontSize: '1.25rem', fontWeight: 700, marginBottom: '0.5rem', lineHeight: 1.3 }}>
                      {article.title}
                    </h3>
                    <div style={{ fontSize: '0.9rem', color: 'var(--text-secondary)' }}>
                      ⏱ {article.readTime} Read
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>

      </div>

      {/* Dedicated Trade Section */}
      <div style={{
        background: 'linear-gradient(135deg, var(--primary) 0%, #1e40af 100%)',
        borderRadius: '24px',
        padding: '4rem',
        textAlign: 'center',
        marginBottom: '5rem',
        color: 'white',
        boxShadow: '0 20px 40px rgba(59, 130, 246, 0.2)'
      }}>
        <h2 style={{ fontSize: '2.5rem', fontWeight: 800, marginBottom: '1rem' }}>Ready to Take a Position?</h2>
        <p style={{ fontSize: '1.2rem', marginBottom: '2.5rem', opacity: 0.9, maxWidth: '600px', margin: '0 auto 2.5rem' }}>
          Join thousands of traders on Polymarket. Get the best odds and deepest liquidity in the industry.
        </p>
        <a href={POLYMARKET_REFERRAL} target="_blank" rel="noopener noreferrer" className="btn" style={{
          background: 'white',
          color: 'var(--primary)',
          fontSize: '1.2rem',
          padding: '1rem 3rem',
          fontWeight: 700,
          borderRadius: '12px'
        }}>
          Trade on Polymarket
        </a>
      </div>

      {/* Newsletter Subscription Section */}
      <NewsletterSection />
    </main>
  );
}
