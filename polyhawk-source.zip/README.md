This is the **Poly Scope** project, a prediction market aggregator.

## Getting Started

1.  **Install dependencies**:
    ```bash
    npm install
    ```

2.  **Run the development server**:
    ```bash
    npm run dev
    ```

3.  **Open the app**:
    Open [http://localhost:3000](http://localhost:3000) with your browser.

## Features

-   **Home Page**: Lists top prediction markets with real-time (mock) data.
-   **Market Details**: Click on any market to see detailed statistics, price history (mock chart), and actionable buttons.
-   **Search**: Functional search bar (visual only for now).
-   **Responsive Design**: Works on mobile and desktop.

## Technologies

-   **Next.js 15**: App Router framework.
-   **Vanilla CSS**: Custom styling with variables for easy theming.
-   **TypeScript**: Type safety for market data.
