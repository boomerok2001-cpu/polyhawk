import { NextResponse } from 'next/server';

export const revalidate = 300; // Cache for 5 minutes

export async function GET(request: Request) {
    const { searchParams } = new URL(request.url);
    const timePeriod = searchParams.get('timePeriod') || 'all';
    const limit = searchParams.get('limit') || '50';
    const sortBy = searchParams.get('sortBy') || 'PNL'; // PNL or VOL

    try {
        const url = `https://data-api.polymarket.com/v1/leaderboard?timePeriod=${timePeriod}&orderBy=${sortBy}&limit=${limit}`;
        const response = await fetch(url);

        if (!response.ok) {
            throw new Error(`Polymarket API error: ${response.status}`);
        }

        const data = await response.json();
        return NextResponse.json(data);
    } catch (error) {
        console.error('Error fetching leaderboard:', error);
        return NextResponse.json({ error: 'Failed to fetch leaderboard' }, { status: 500 });
    }
}
