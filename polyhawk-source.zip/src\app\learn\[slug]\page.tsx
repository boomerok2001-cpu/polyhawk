import Link from 'next/link';

// Map slugs to images for demo purposes
const ARTICLE_IMAGES: Record<string, string> = {
    'what-are-prediction-markets': 'https://images.unsplash.com/photo-1642543492481-44e81e3914a7?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80',
    'how-to-arbitrage': 'https://images.unsplash.com/photo-1611974765270-ca1258634369?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80',
    'polymarket-vs-kalshi': 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80'
};

const ARTICLE_CONTENT: Record<string, { title: string; date: string; readTime: string; content: React.ReactNode }> = {
    'what-are-prediction-markets': {
        title: 'What Are Prediction Markets?',
        date: 'Dec 20, 2024',
        readTime: '5 min read',
        content: (
            <>
                <p>Prediction markets are exchange-traded markets created for the purpose of trading the outcome of events. The market prices can indicate what the crowd thinks the probability of the event is.</p>
                <h2>How it works</h2>
                <p>Prediction markets allow you to buy shares in the outcome of an event. For example, will Bitcoin hit $100k? You can buy "Yes" or "No" shares.</p>
                <p>If you buy a "Yes" share for 60 cents and the event happens, the share pays out $1.00. Your profit is 40 cents (67% ROI). If it doesn't happen, the share is worth $0.</p>
                <h2>Why use them?</h2>
                <ul>
                    <li>Hedge against real-world risks (e.g., inflation, elections)</li>
                    <li>Profit from your knowledge/alpha</li>
                    <li>Get unbiased probability data</li>
                </ul>
            </>
        )
    },
    'how-to-arbitrage': {
        title: 'Arbitrage Strategy 101',
        date: 'Dec 21, 2024',
        readTime: '8 min read',
        content: (
            <>
                <p>Arbitrage in prediction markets involves exploiting price differences for the same event across different platforms, such as Polymarket and Kalshi.</p>
                <h2>The Concept</h2>
                <p>If Polymarket prices "Yes" at 60¢ (implied 60%) and Kalshi prices "No" at 45¢ (implied 45% for No, meaning 55% for Yes), there is a discrepancy.</p>
                <p>However, true arbitrage usually involves buying 'Yes' on one platform and 'No' on another when the total cost is less than $1.00.</p>
                <h2>Example Setup</h2>
                <ul>
                    <li><strong>Polymarket:</strong> Buy "Trump Wins" (Yes) at 55¢.</li>
                    <li><strong>Kalshi:</strong> Buy "Trump Loses" (Yes on 'Harris Wins' or equivalent) at 43¢.</li>
                    <li><strong>Total Cost:</strong> 98¢.</li>
                    <li><strong>Payout:</strong> $1.00 regardless of who wins.</li>
                    <li><strong>Risk-Free Profit:</strong> 2¢ per share (roughly 2% ROI instantly).</li>
                </ul>
                <p>While 2% seems small, these opportunities can compound quickly if volume allows.</p>
            </>
        )
    },
    'understanding-order-books': {
        title: 'Reading the Order Book',
        date: 'Dec 21, 2024',
        readTime: '10 min read',
        content: (
            <>
                <p>The order book is the heartbeat of any market. It shows the list of buyers (bids) and sellers (asks) waiting to execute trades.</p>
                <h2>Bid vs. Ask</h2>
                <p><strong>Bid:</strong> The highest price someone is willing to pay for a share immediately.</p>
                <p><strong>Ask:</strong> The lowest price someone is willing to sell a share for immediately.</p>
                <h2>Liquidity Depth</h2>
                <p>A "deep" order book means there are many orders at prices close to the last traded price. This allows you to trade large sizes without moving the price significantly (low slippage).</p>
                <p>In thin markets, a $500 buy order might push the price from 50¢ to 65¢, resulting in a terrible average entry price. Always check depth before aping in.</p>
            </>
        )
    },
    'polymarket-vs-kalshi': {
        title: 'Polymarket vs. Kalshi: A Comparison',
        date: 'Dec 19, 2024',
        readTime: '6 min read',
        content: (
            <>
                <p>The two titans of the prediction market industry offer very different experiences.</p>
                <h2>Polymarket</h2>
                <ul>
                    <li><strong>Crypto-native:</strong> Runs on Polygon (USDC).</li>
                    <li><strong>Volume:</strong> Generally much higher volume and variety.</li>
                    <li><strong>Regulation:</strong> Offshore, technically not for US residents (though VPN usage is open secret).</li>
                    <li><strong>UX:</strong> Fast, web3 login, instant settlement.</li>
                </ul>
                <h2>Kalshi</h2>
                <ul>
                    <li><strong>Regulated:</strong> CFTC regulated exchange for US residents.</li>
                    <li><strong>Currency:</strong> USD (Bank deposits).</li>
                    <li><strong>Limits:</strong> Individual position limits exist per event.</li>
                    <li><strong>Taxes:</strong> Issues 1099-B tax forms, simplifying reporting.</li>
                </ul>
                <p>Choosing between them often depends on your location and comfort with crypto rails.</p>
            </>
        )
    },
    'managing-risk-bankroll': {
        title: 'Bankroll Management for Traders',
        date: 'Dec 22, 2024',
        readTime: '7 min read',
        content: (
            <>
                <p>The number one reason traders fail is not bad predictions, but bad sizing. You can be right 60% of the time and still go broke if you bet too big.</p>
                <h2>The Kelly Criterion</h2>
                <p>Many pros use a fractional Kelly strategy. The formula calculates the optimal bet size based on your edge.</p>
                <p><code>f = (bp - q) / b</code></p>
                <p>Where <em>b</em> is odds received - 1, <em>p</em> is probability of winning, and <em>q</em> is probability of losing.</p>
                <h2>Simple Rule of Thumb</h2>
                <p>Never bet more than 1-5% of your total bankroll on a single outcome, no matter how "sure" you feel.</p>
                <p>Prediction markets are binary. Prices can go to 0 very fast. Survival is the first goal.</p>
            </>
        )
    },
    'identifying-positive-ev': {
        title: 'Finding +EV Opportunities',
        date: 'Dec 22, 2024',
        readTime: '12 min read',
        content: (
            <>
                <p>+EV means "Positive Expected Value". It marks a bet that will be profitable in the long run.</p>
                <h2>Calculating EV</h2>
                <p>Formula: <code>(Probability of Win * Potential Profit) - (Probability of Loss * Amount Risked)</code></p>
                <h2>Example</h2>
                <p>You think there is a 70% chance it rains tomorrow. The "Yes" share for rain is trading at 50¢.</p>
                <ul>
                    <li><strong>Win Scenario:</strong> 70% chance to win 50¢ profit. (0.7 * 0.50 = 0.35)</li>
                    <li><strong>Loss Scenario:</strong> 30% chance to lose 50¢ stake. (0.3 * 0.50 = 0.15)</li>
                    <li><strong>EV:</strong> 0.35 - 0.15 = +$0.20 per share.</li>
                </ul>
                <p>Since the result is positive, this is a +EV trade. If you make this trade 100 times, you will statistically make money.</p>
            </>
        )
    },
    'regulatory-landscape': {
        title: 'The Future of Regulation',
        date: 'Dec 18, 2024',
        readTime: '5 min read',
        content: (
            <>
                <p>Regulation is heating up in the US. The CFTC has historically taken a hard stance against event contracts, viewing them as gaming/gambling.</p>
                <h2>Recent Shifts</h2>
                <p>However, recent court rulings regarding Kalshi have paved the way for "election markets" to be legal in the US.</p>
                <p>This legitimacy brings institutional liquidity but also stricter compliance requirements (KYC, AML) that defied usage on offshore crypto platforms like Polymarket.</p>
            </>
        )
    },
    'impact-of-news-on-markets': {
        title: 'Trading News Events',
        date: 'Dec 22, 2024',
        readTime: '9 min read',
        content: (
            <>
                <p>Markets react to news, but prediction markets react specifically to <em>confirmation</em>.</p>
                <h2>Speed is Key</h2>
                <p>When AP calls an election state, the market might move from 60¢ to 99¢ in seconds. Bots often front-run this.</p>
                <h2>The "Buy the Rumor, Sell the News" trap</h2>
                <p>In prediction markets, holding through the event resolution is risky unless the outcome is mathematically certain. Often, traders will sell right before the official announcement to lock in profits and avoid any last-minute "black swan" reversals.</p>
            </>
        )
    },
    'correlation-trading': {
        title: 'Correlation Trading Strategies',
        date: 'Dec 21, 2024',
        readTime: '11 min read',
        content: (
            <>
                <p>Events don't happen in a vacuum. A win for a pro-crypto candidate often correlates with a rise in Bitcoin price.</p>
                <h2>Cross-Market Plays</h2>
                <p>If you see Bitcoin pumping strictly due to election odds improving, you might find that the "Bitcoin &gt; 100k" share is lagging behind the "Candidate Wins" share.</p>
                <p>If Candidate X winning implies Bitcoin moons, but Candidate X shares are up 20% and Bitcoin shares are flat, that is a mispricing opportunity.</p>
            </>
        )
    }
};

export default async function ArticlePage({ params }: { params: Promise<{ slug: string }> }) {
    const { slug } = await params;

    const articleData = ARTICLE_CONTENT[slug] || {
        title: slug.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' '),
        date: 'Recently Updated',
        readTime: '5 min read',
        content: <p>Article content coming soon...</p>
    };

    const heroImage = ARTICLE_IMAGES[slug] || 'https://images.unsplash.com/photo-1590283603385-17ffb3a7f29f?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80';

    return (
        <main className="container" style={{ paddingBottom: '4rem', maxWidth: '800px' }}>
            <Link href="/learn" style={{ display: 'inline-block', marginTop: '2rem', color: 'var(--text-secondary)', textDecoration: 'none' }}>
                &larr; Back to Academy
            </Link>

            <article style={{ marginTop: '2rem' }}>
                <div style={{ width: '100%', height: '400px', borderRadius: '24px', overflow: 'hidden', marginBottom: '2rem' }}>
                    <img src={heroImage} alt={slug} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                </div>
                <h1 style={{ fontSize: '3rem', fontWeight: 800, marginBottom: '1.5rem', lineHeight: 1.2 }}>
                    {articleData.title}
                </h1>

                <div style={{ display: 'flex', gap: '2rem', color: 'var(--text-secondary)', marginBottom: '3rem', paddingBottom: '2rem', borderBottom: '1px solid var(--border)' }}>
                    <span>📅 {articleData.date}</span>
                    <span>✍️ Poly Team</span>
                    <span>⏱ {articleData.readTime}</span>
                </div>

                <div className="prose" style={{ lineHeight: 1.8, fontSize: '1.1rem', color: 'var(--text-secondary)' }}>
                    {articleData.content}

                    <div style={{ background: 'var(--surface)', padding: '2rem', borderRadius: '12px', borderLeft: '4px solid var(--primary)', marginTop: '3rem' }}>
                        <h3 style={{ marginTop: 0, color: 'var(--text-main)' }}>Ready to start?</h3>
                        <p style={{ marginBottom: 0 }}>Check out our <Link href="/arbitrage" style={{ color: 'var(--primary)' }}>Arbitrage Dashboard</Link> to find risk-free opportunities.</p>
                    </div>
                </div>
            </article>
        </main>
    );
}
