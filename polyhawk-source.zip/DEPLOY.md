# How to Deploy Poly Hawk

Since this is a secure CLI tool, you must authenticate it manually once.

## Step 1: Run the Deploy Script
In your terminal, run:

```bash
.\deploy.bat
```

## Step 2: Follow Protocol
1.  If asked to **Log in**, choose **Continue with GitHub** or **Email**. A browser window will open.
2.  **Confirm** the login in the browser.
3.  Return to the terminal.
4.  Accept default settings (press `Enter` 4-5 times):
    *   Set up and deploy? **Y**
    *   Which scope? **(Your Name)**
    *   Link to existing project? **N**
    *   Project Name? **poly-hawk**
    *   Code Location? **./**

## Step 3: Success
Vercel will build the project and give you a `Production` link (e.g., `https://poly-hawk.vercel.app`).
