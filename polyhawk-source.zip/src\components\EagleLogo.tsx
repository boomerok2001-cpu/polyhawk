export default function EagleLogo({ size = 40 }: { size?: number }) {
    return (
        <div style={{ width: `${size}px`, height: `${size}px`, marginRight: '10px' }}>
            <img
                src="/eagle.png"
                alt="Poly Hawk Eagle"
                style={{ width: '100%', height: '100%', objectFit: 'contain' }}
            />
        </div>
    );
}
