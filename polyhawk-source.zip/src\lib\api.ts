// Polymarket Referral Link
export const POLYMARKET_REFERRAL = 'https://polymarket.com/?via=shiroe';

export function getPolymarketUrl(path: string = ''): string {
    const baseUrl = 'https://polymarket.com';
    const referralParam = 'via=shiroe';

    if (!path) return `${baseUrl}/?${referralParam}`;

    // Check if path already has query params
    const separator = path.includes('?') ? '&' : '?';
    return `${baseUrl}/${path.replace(/^\//, '')}${separator}${referralParam}`;
}

// Update Market interface to include URL
export interface Market {
    id: string;
    title: string;
    category: string;
    source: 'Polymarket' | 'Kalshi';
    yesPrice: number;
    noPrice: number;
    volume: number;
    liquidity: number;
    change24h: number;
    endDate?: string;
    image?: string;
    url: string; // Added for redirection
}

export interface NewsItem {
    id: string;
    title: string;
    source: string;
    time: string;
    category: string;
    url: string;
    snippet: string;
    sentiment: 'Positive' | 'Negative' | 'Neutral';
    imageUrl: string;
}

export async function fetchNews(): Promise<NewsItem[]> {
    try {
        const news: NewsItem[] = [];

        // 1. Fetch CoinDesk RSS (Real-time updates)
        try {
            const feedResponse = await fetch('https://www.coindesk.com/arc/outboundfeeds/rss/?outputType=xml', { next: { revalidate: 300 } });
            const feedText = await feedResponse.text();

            // Simple regex parsing specifically for RSS items to avoid heavy dependencies
            // Limiting to first 10 items
            const itemRegex = /<item>[\s\S]*?<\/item>/g;
            const items = feedText.match(itemRegex)?.slice(0, 10) || [];

            items.forEach((item, index) => {
                const titleMatch = item.match(/<title><!\[CDATA\[(.*?)\]\]><\/title>/) || item.match(/<title>(.*?)<\/title>/);
                const linkMatch = item.match(/<link>(.*?)<\/link>/);
                const dateMatch = item.match(/<pubDate>(.*?)<\/pubDate>/);
                const descMatch = item.match(/<description>[\s\S]*?<!\[CDATA\[(.*?)\]\]>/) || item.match(/<description>(.*?)<\/description>/);
                const mediaMatch = item.match(/media:content[^>]*url="(.*?)"/) || item.match(/<enclosure[^>]*url="(.*?)"/);

                if (titleMatch && linkMatch) {
                    const title = titleMatch[1];
                    const date = dateMatch ? new Date(dateMatch[1]) : new Date();
                    // Calculate "time ago"
                    const hoursAgo = Math.floor((Date.now() - date.getTime()) / (1000 * 60 * 60));

                    news.push({
                        id: `cd-${index}`,
                        title: title.replace(/&amp;/g, '&'),
                        source: 'CoinDesk',
                        time: hoursAgo < 1 ? 'Just now' : `${hoursAgo}h ago`,
                        category: title.includes('Bitcoin') ? 'Bitcoin' : title.includes('ETF') ? 'Regulation' : 'Market',
                        url: linkMatch[1],
                        snippet: descMatch ? descMatch[1].replace(/<[^>]*>/g, '').substring(0, 100) + '...' : 'Latest update from CoinDesk.',
                        sentiment: title.toLowerCase().includes('bull') || title.toLowerCase().includes('rise') ? 'Positive' : 'Neutral',
                        imageUrl: mediaMatch ? mediaMatch[1] : 'https://images.unsplash.com/photo-1621504450168-38f64731b667?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
                    });
                }
            });
        } catch (rssError) {
            console.error('RSS Fetch Failed', rssError);
            // Non-critical, continue to next source
        }

        // 2. Fetch Polymarket "New" events acting as news
        try {
            const polyResponse = await fetch('https://gamma-api.polymarket.com/events?limit=8&active=true&closed=false&order=volume24hr&ascending=false', { next: { revalidate: 60 } });
            const polyData = await polyResponse.json();

            polyData.forEach((event: any, i: number) => {
                news.push({
                    id: `poly-news-${event.id}`,
                    title: `New Market: ${event.title}`,
                    source: 'Polymarket',
                    time: 'Live',
                    category: 'New Listing',
                    url: getPolymarketUrl(`event/${event.slug}`),
                    snippet: `Huge volume detected on ${event.title}. Trade now on Polymarket.`,
                    sentiment: 'Neutral',
                    imageUrl: event.image || 'https://images.unsplash.com/photo-1611974765270-ca1258634369?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
                });
            });
        } catch (e) {
            // ignore
        }

        // 3. Fallback / Static Mix-in if we have very little news
        if (news.length < 8) {
            const staticNews = [
                {
                    id: 'static-1',
                    title: 'Bloomberg: Prediction Markets See Record Inflows',
                    source: 'Bloomberg',
                    time: '4h ago',
                    category: 'Adoption',
                    url: 'https://bloomberg.com/crypto',
                    snippet: 'Institutional interest is peaking as global uncertainty rises.',
                    sentiment: 'Positive' as const,
                    imageUrl: 'https://images.unsplash.com/photo-1526304640155-b46e53e75d53?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
                },
                {
                    id: 'static-2',
                    title: 'Polymarket Surpasses $1B in Monthly Volume',
                    source: 'The Block',
                    time: '6h ago',
                    category: 'Markets',
                    url: 'https://theblock.co',
                    snippet: 'Prediction markets continue explosive growth amid election season.',
                    sentiment: 'Positive' as const,
                    imageUrl: 'https://images.unsplash.com/photo-1611974765270-ca1258634369?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
                },
                {
                    id: 'static-3',
                    title: 'Kalshi Launches New Sports Betting Markets',
                    source: 'CoinTelegraph',
                    time: '8h ago',
                    category: 'Sports',
                    url: 'https://cointelegraph.com',
                    snippet: 'CFTC-regulated platform expands into sports prediction markets.',
                    sentiment: 'Neutral' as const,
                    imageUrl: 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
                },
                {
                    id: 'static-4',
                    title: 'Crypto Prediction Markets Gain Mainstream Attention',
                    source: 'Forbes',
                    time: '12h ago',
                    category: 'Adoption',
                    url: 'https://forbes.com/crypto',
                    snippet: 'Wall Street analysts highlight prediction markets as the future of forecasting.',
                    sentiment: 'Positive' as const,
                    imageUrl: 'https://images.unsplash.com/photo-1590283603385-17ffb3a7f29f?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
                }
            ];
            news.push(...staticNews.slice(0, 8 - news.length));
        }

        // Sort by recency (simulated by ID or list order in this simple agg)
        return news.sort(() => 0.5 - Math.random()); // Shuffle slightly for variety
    } catch (error) {
        console.error('FetchNews Error', error);
        // Absolute fallback
        return [
            {
                id: 'fallback-1',
                title: 'Prediction Markets Continue to Grow',
                source: 'Poly Gecko',
                time: 'Recently',
                category: 'General',
                url: '#',
                snippet: 'Markets are heating up.',
                sentiment: 'Positive',
                imageUrl: 'https://images.unsplash.com/photo-1590283603385-17ffb3a7f29f?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
            }
        ];
    }
}

export async function fetchPolymarketTrending(): Promise<Market[]> {
    try {
        const response = await fetch('https://gamma-api.polymarket.com/events?limit=100&active=true&closed=false&order=volume24hr&ascending=false', {
            cache: 'no-store'
        });
        const data = await response.json();

        return data.map((event: any) => {
            const market = event.markets?.[0] || event;
            if (!market) return null;

            const outcomePrices = JSON.parse(market.outcomePrices || '["0.5", "0.5"]');
            const volume = parseFloat(market.volume24hr || '0');
            const liquidity = parseFloat(market.liquidity || '0');

            return {
                id: event.id,
                title: event.title || event.question,
                category: event.tags?.[0]?.label || 'General',
                source: 'Polymarket',
                yesPrice: parseFloat(outcomePrices[0] || '0'),
                noPrice: parseFloat(outcomePrices[1] || '0'),
                volume: volume,
                liquidity: liquidity,
                change24h: (Math.random() * 10) - 5,
                url: getPolymarketUrl(`event/${event.slug || event.id}`) // Construct URL
            };
        }).filter(Boolean);
    } catch (error) {
        console.error('Error fetching Polymarket:', error);
        return [];
    }
}

export async function fetchTopGainers(): Promise<Market[]> {
    // For demo, we'll fetch trending and filter/sort by high fake change %
    const markets = await fetchPolymarketTrending();
    return markets
        .map(m => ({ ...m, change24h: Math.random() * 50 + 10 })) // Simulate high gains (10-60%)
        .sort((a, b) => b.change24h - a.change24h)
        .slice(0, 4);
}

// Re-using the generic fetch for specific endpoint requirements
export async function fetchSportsMarkets(): Promise<Market[]> {
    // Fetch specifically for homepage display (limit 6)
    const markets = await fetchMarketsByCategory('sports');
    return markets.slice(0, 6);
}

export async function fetchMarketsByCategory(category: string): Promise<Market[]> {
    try {
        // Fetch from Polymarket
        const tag = category.toLowerCase();
        const polyResponse = await fetch(`https://gamma-api.polymarket.com/events?limit=30&tag_slug=${tag}&active=true&closed=false&order=volume24hr&ascending=false`, { next: { revalidate: 10 } });
        const polyData = await polyResponse.json();
        const polyMarkets = mapPolymarketData(polyData);

        // Fetch from Kalshi (filter by category after fetching)
        const kalshiMarkets = await fetchKalshiMarkets();
        const kalshiFiltered = kalshiMarkets.filter(m =>
            m.category.toLowerCase().includes(category.toLowerCase()) ||
            category.toLowerCase().includes(m.category.toLowerCase())
        ).slice(0, 20);

        // Merge and sort by volume
        return [...polyMarkets, ...kalshiFiltered]
            .sort((a, b) => b.volume - a.volume)
            .slice(0, 50);
    } catch (e) {
        console.error('Error fetching category markets:', e);
        return [];
    }
}

export async function fetchKalshiMarkets(): Promise<Market[]> {
    // ... (fetch implementation)
    // inside the try:
    try {
        const response = await fetch('https://api.elections.kalshi.com/trade-api/v2/markets?limit=100&status=active', {
            cache: 'no-store',
            signal: AbortSignal.timeout(5000)
        });

        if (!response.ok) throw new Error("Fallback needed");

        const data = await response.json();
        if (!data.markets) return [];

        return data.markets.map((market: any) => {
            return {
                id: market.ticker,
                title: market.title,
                category: market.category,
                source: 'Kalshi',
                yesPrice: (market.yes_ask || 0) / 100,
                noPrice: (market.no_ask || 0) / 100,
                volume: market.volume || 0,
                liquidity: market.open_interest || 0,
                change24h: 0,
                url: `https://kalshi.com/markets/${market.ticker}`
            };
        });
    } catch (error) {
        // Fallback
        return [
            { id: 'KX-FED-RATE', title: 'Fed Rates Unchanged?', category: 'Economics', source: 'Kalshi', yesPrice: 0.85, noPrice: 0.15, volume: 150000, liquidity: 50000, change24h: 0, url: 'https://kalshi.com' },
            { id: 'KX-GDP-US', title: 'US GDP Growth > 2%?', category: 'Economics', source: 'Kalshi', yesPrice: 0.60, noPrice: 0.40, volume: 80000, liquidity: 25000, change24h: 0, url: 'https://kalshi.com' },
            { id: 'KX-CPI', title: 'CPI < 3.0%?', category: 'Economics', source: 'Kalshi', yesPrice: 0.30, noPrice: 0.70, volume: 220000, liquidity: 100000, change24h: 0, url: 'https://kalshi.com' },
        ];
    }
}

export async function fetchNewMarkets(): Promise<Market[]> {
    try {
        // Fetch new markets from Polymarket
        const polyResponse = await fetch('https://gamma-api.polymarket.com/events?limit=15&active=true&closed=false&order=volume24hr&ascending=false', { next: { revalidate: 10 } });
        const polyData = await polyResponse.json();
        const polyMarkets = mapPolymarketData(polyData);

        // Fetch from Kalshi and assume recent ones are "new"
        const kalshiMarkets = await fetchKalshiMarkets();
        const recentKalshi = kalshiMarkets.slice(0, 10);

        // Merge both sources
        return [...polyMarkets, ...recentKalshi]
            .sort((a, b) => b.volume - a.volume)
            .slice(0, 25);
    } catch (e) {
        console.error('Error fetching new markets:', e);
        return [];
    }
}

export async function fetchResolvedMarkets(): Promise<Market[]> {
    try {
        // Fetch resolved markets from Polymarket
        const polyResponse = await fetch('https://gamma-api.polymarket.com/events?limit=20&active=false&closed=true&order=volume24hr&ascending=false', { next: { revalidate: 10 } });
        const polyData = await polyResponse.json();
        const polyMarkets = mapPolymarketData(polyData);

        // Note: Kalshi doesn't have a simple "resolved" endpoint in their public API
        // For now, just return Polymarket resolved markets
        // In production, you'd query Kalshi's historical/settled markets endpoint

        return polyMarkets.slice(0, 25);
    } catch (e) {
        console.error('Error fetching resolved markets:', e);
        return [];
    }
}

// Helper to map raw polymarket data to our interface
function mapPolymarketData(data: any[]): Market[] {
    return data.map((event: any) => {
        const market = event.markets?.[0] || event;
        if (!market) return null;
        const outcomePrices = JSON.parse(market.outcomePrices || '["0.5", "0.5"]');
        return {
            id: event.id,
            title: event.title || event.question,
            category: event.tags?.[0]?.label || 'General',
            source: 'Polymarket' as const,
            yesPrice: parseFloat(outcomePrices[0] || '0'),
            noPrice: parseFloat(outcomePrices[1] || '0'),
            volume: parseFloat(market.volume24hr || '0'),
            liquidity: parseFloat(market.liquidity || '0'),
            change24h: 0,
            url: getPolymarketUrl(`event/${event.slug || event.id}`),
            image: event.image
        } as Market;
    }).filter((m): m is Market => m !== null);
}

// ... (HistoryPoint stuff)
export interface HistoryPoint {
    time: string;
    price: number;
}
export async function fetchMarketHistory(id: string): Promise<HistoryPoint[]> {
    const points: HistoryPoint[] = [];
    let price = 0.5 + (Math.random() * 0.4 - 0.2);
    const now = Date.now();
    for (let i = 24; i >= 0; i--) {
        const time = new Date(now - i * 60 * 60 * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        const change = (Math.random() - 0.5) * 0.05;
        price += change;
        if (price > 0.99) price = 0.99;
        if (price < 0.01) price = 0.01;
        points.push({ time, price });
    }
    return points;
}


export interface Signal {
    id: string;
    type: 'WHALE' | 'SPIKE' | 'INSIDER' | 'TWITTER';
    marketTitle: string;
    description: string;
    timestamp: string;
    severity: 'HIGH' | 'MEDIUM';
    sourceName?: string; // e.g. "Whale Alert", "Hsaka"
    sourceUrl?: string;
}

export async function fetchSignals(): Promise<Signal[]> {
    const markets = await fetchPolymarketTrending();
    const signals: Signal[] = [];

    // 1. Simulating Twitter/Insider Signals
    signals.push({
        id: 'tw-1',
        type: 'TWITTER',
        marketTitle: 'Election 2024 Winner',
        description: 'New poll aggregation shows slight swing in key states. Market adjusting rapidly. @PolymarketWhale says "Buy the dip".',
        timestamp: '10m ago',
        severity: 'MEDIUM',
        sourceName: '@PolymarketWhale',
        sourceUrl: 'https://twitter.com'
    });

    signals.push({
        id: 'ins-1',
        type: 'INSIDER',
        marketTitle: 'Pending Regulation Approval',
        description: 'Unusual specialized betting pattern detected from wallet 0x8...A2. Possible insider knowledge on CFTC ruling.',
        timestamp: '45m ago',
        severity: 'HIGH',
        sourceName: 'ChainAnalysis Bot',
        sourceUrl: '#'
    });

    // 2. Detect Price Spikes (> 10%)
    markets.forEach(m => {
        if (Math.abs(m.change24h) > 12) {
            signals.push({
                id: `sig-${m.id}`,
                type: 'SPIKE',
                marketTitle: m.title,
                description: `${m.change24h > 0 ? 'Surged' : 'Crashed'} by ${m.change24h.toFixed(1)}% in the last 24h.`,
                timestamp: 'Just now',
                severity: 'HIGH'
            });
        }
        if (m.volume > 2000000) {
            signals.push({
                id: `whale-${m.id}`,
                type: 'WHALE',
                marketTitle: m.title,
                description: `Massive volume spike! $${(m.volume / 1000000).toFixed(1)}M traded.`,
                timestamp: '1h ago',
                severity: 'MEDIUM'
            });
        }
    });

    return signals.slice(0, 10); // Limit to 10
}

export interface ArbitrageOpportunity {
    market1: Market;
    market2: Market;
    spread: number; // Percentage profit
    event: string;
}

export async function findArbitrageOpportunities(mode: 'demo' | 'strict' = 'demo'): Promise<ArbitrageOpportunity[]> {
    const [poly, kalshi] = await Promise.all([
        fetchPolymarketTrending(),
        fetchKalshiMarkets()
    ]);

    const opportunities: ArbitrageOpportunity[] = [];

    // STRICT MODE: Real mathematical arbitrage only
    if (mode === 'strict') {
        for (const p of poly) {
            for (const k of kalshi) {
                // strict matching logic (share significant words)
                const pWords = p.title.toLowerCase().split(' ').filter(w => w.length > 3);
                const kWords = k.title.toLowerCase().split(' ').filter(w => w.length > 3);
                const intersection = pWords.filter(w => kWords.includes(w));

                if (intersection.length >= 2) { // Must share at least 2 words
                    // Check for price discrepancy
                    // Arbitrage exists if:
                    // 1. Buy Yes on A + Buy No on B < 1.00
                    // 2. Buy No on A + Buy Yes on B < 1.00

                    const cost1 = p.yesPrice + (k.noPrice || (1 - k.yesPrice));
                    const cost2 = p.noPrice + (k.yesPrice || (1 - k.noPrice));

                    if (cost1 < 0.995) { // 0.5% buffer for fees (more lenient)
                        opportunities.push({
                            market1: { ...p, yesPrice: p.yesPrice }, // Buy Yes
                            market2: { ...k, noPrice: k.noPrice },   // Buy No
                            spread: (1 - cost1) * 100,
                            event: `${p.title} (Yes/No)`
                        });
                    }
                    if (cost2 < 0.995) {
                        opportunities.push({
                            market1: { ...p, noPrice: p.noPrice },   // Buy No
                            market2: { ...k, yesPrice: k.yesPrice }, // Buy Yes
                            spread: (1 - cost2) * 100,
                            event: `${p.title} (No/Yes)`
                        });
                    }
                }
            }
        }
        return opportunities;
    }

    // DEMO MODE (Existing Logic)
    // Relaxed matching to show "potential" opportunities for UI demonstration
    const maxOpp = 15; // Increased from 5
    let count = 0;

    for (const p of poly) {
        if (count >= maxOpp) break;

        // Try strict match first
        for (const k of kalshi) {
            const pWords = p.title.toLowerCase().split(' ').filter(w => w.length > 3);
            const kWords = k.title.toLowerCase().split(' ').filter(w => w.length > 3);
            const intersection = pWords.filter(w => kWords.includes(w));

            // MATCH FOUND or Forced Match for demo if categories align
            if (intersection.length >= 1 || (p.category === k.category && Math.random() > 0.8)) {

                // Demo: Force a spread that looks real
                // We'll just generate a "spread" based on the fact we found a match
                // In reality, we'd calculate p.yesPrice + k.noPrice < 1.0

                const spread = Math.random() * 5 + 1; // 1% to 6% profit

                opportunities.push({
                    market1: p,
                    market2: k,
                    spread: spread,
                    event: p.title // Use Poly title as main
                });
                count++;
                break; // One match per poly market
            }
        }
    }

    // Always ensure at least a few items for the user
    if (opportunities.length < 3) {
        // Add existing fallback plus a few more
        opportunities.push({
            market1: { ...poly[0], yesPrice: 0.40, source: 'Polymarket' } as Market,
            market2: { ...poly[0], id: 'mock-k', source: 'Kalshi', yesPrice: 0.55, noPrice: 0.40 } as Market,
            spread: 20,
            event: "Bitcoin > $100k (Arbitrage Pair)"
        });
        opportunities.push({
            market1: { ...poly[1] || poly[0], yesPrice: 0.65, source: 'Polymarket' } as Market,
            market2: { ...poly[1] || poly[0], id: 'mock-k2', source: 'Kalshi', yesPrice: 0.45, noPrice: 0.30 } as Market,
            spread: 5,
            event: "Fed Interest Rate Hike"
        });
    }

    return opportunities;
}

export async function fetchAllMarkets(): Promise<Market[]> {
    const [poly, kalshi] = await Promise.all([
        fetchPolymarketTrending(),
        fetchKalshiMarkets()
    ]);

    // Interleave results for a mixed feel
    const mixed: Market[] = [];
    const maxLen = Math.max(poly.length, kalshi.length);

    for (let i = 0; i < maxLen; i++) {
        if (poly[i]) mixed.push(poly[i]);
        if (kalshi[i]) mixed.push(kalshi[i]);
    }

    return mixed;
}
