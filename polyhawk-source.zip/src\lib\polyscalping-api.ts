/**
 * Polyscalping API Client
 * Fetches market data from polyscalping.org including spreads, liquidity, and volume metrics
 */

const POLYSCALPING_API_URL = 'https://api.polyscalping.org/api/data';

export interface PolyscalpingMarket {
    id: number;
    market: string;
    marketSlug: string;
    eventSlug: string;
    category: string;
    lastPrice: number;
    bidPrice: number;
    askPrice: number;
    liquidity: number;
    volume24h: number;
    priceChange24h: number;
    priceChange1h: number;
    spread: number;
    spreadPercent: number;
    tags: string[];
    image: string;
    conditionId: string;
    createdAt: string;
    endDate: string | null;
    rewardsDailyRate: number;
}

export interface PolyscalpingResponse {
    success: boolean;
    count: number;
    lastUpdate: string;
    data: PolyscalpingMarket[];
}

export interface PolyscalpingEvent {
    eventSlug: string;
    eventName: string;
    category: string;
    markets: PolyscalpingMarket[];
    totalVolume: number;
    avgSpread: number;
    marketCount: number;
}

/**
 * Fetch all markets from polyscalping API
 */
export async function fetchPolyscalpingMarkets(): Promise<PolyscalpingMarket[]> {
    try {
        const response = await fetch(POLYSCALPING_API_URL, {
            next: { revalidate: 60 } // Cache for 60 seconds
        });

        if (!response.ok) {
            throw new Error(`Polyscalping API error: ${response.status}`);
        }

        const data: PolyscalpingResponse = await response.json();

        if (!data.success || !data.data) {
            throw new Error('Invalid response from polyscalping API');
        }

        return data.data;
    } catch (error) {
        console.error('Error fetching polyscalping markets:', error);
        return [];
    }
}

/**
 * Fetch markets grouped by event
 */
export async function fetchPolyscalpingEvents(): Promise<PolyscalpingEvent[]> {
    try {
        const markets = await fetchPolyscalpingMarkets();

        // Group markets by eventSlug
        const eventMap = new Map<string, PolyscalpingMarket[]>();

        markets.forEach(market => {
            const slug = market.eventSlug;
            if (!eventMap.has(slug)) {
                eventMap.set(slug, []);
            }
            eventMap.get(slug)!.push(market);
        });

        // Convert to array of events with aggregated metrics
        const events: PolyscalpingEvent[] = Array.from(eventMap.entries()).map(([slug, markets]) => {
            const totalVolume = markets.reduce((sum, m) => sum + m.volume24h, 0);
            const avgSpread = markets.reduce((sum, m) => sum + m.spreadPercent, 0) / markets.length;

            return {
                eventSlug: slug,
                eventName: markets[0].market.split('?')[0], // Use first market's question as event name
                category: markets[0].category,
                markets,
                totalVolume,
                avgSpread,
                marketCount: markets.length
            };
        });

        // Sort by total volume descending
        return events.sort((a, b) => b.totalVolume - a.totalVolume);
    } catch (error) {
        console.error('Error fetching polyscalping events:', error);
        return [];
    }
}

/**
 * Filter markets by category
 */
export async function fetchPolyscalpingMarketsByCategory(category: string): Promise<PolyscalpingMarket[]> {
    try {
        const markets = await fetchPolyscalpingMarkets();
        return markets.filter(m => m.category.toLowerCase() === category.toLowerCase());
    } catch (error) {
        console.error(`Error fetching polyscalping markets for category ${category}:`, error);
        return [];
    }
}

/**
 * Get top markets by volume
 */
export async function fetchPolyscalpingTrending(limit: number = 50): Promise<PolyscalpingMarket[]> {
    try {
        const markets = await fetchPolyscalpingMarkets();
        return markets
            .sort((a, b) => b.volume24h - a.volume24h)
            .slice(0, limit);
    } catch (error) {
        console.error('Error fetching trending polyscalping markets:', error);
        return [];
    }
}
